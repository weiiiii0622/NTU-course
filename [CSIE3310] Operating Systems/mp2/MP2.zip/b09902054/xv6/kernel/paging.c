#include "param.h"
#include "types.h"
#include "memlayout.h"
#include "riscv.h"
#include "spinlock.h"
#include "defs.h"
#include "proc.h"

/* NTU OS 2022 */
/* Page fault handler */
int handle_pgfault() {
  /* Find the address that caused the fault */
  /* uint64 va = r_stval(); */
  uint64 va=PGROUNDDOWN(r_stval());
  pte_t *pte=walk(myproc()->pagetable,va,1);
  if((*pte)&PTE_S)
  {
    char *pa=kalloc();
    memset(pa,0,PGSIZE);
    begin_op();
    read_page_from_disk(ROOTDEV,pa,PTE2BLOCKNO(*pte));
    bfree_page(ROOTDEV,PTE2BLOCKNO(*pte));
    end_op();
    *pte=PA2PTE(pa)|PTE_FLAGS(*pte);
    *pte&=~PTE_S;
    *pte|=PTE_V;
  }
  else
  {
    char *pa=kalloc();
    memset(pa,0,PGSIZE);
    mappages(myproc()->pagetable, va, PGSIZE, (uint64)pa, PTE_U|PTE_R|PTE_W|PTE_X);
  }
  return 0;
}
